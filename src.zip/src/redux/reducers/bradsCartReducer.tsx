import {ActionType} from '../actions';

const InitialBradCartState = {
  Cart: [],
  Prod: [],
};
export default (state = InitialBradCartState, {type, payload}) => {
  switch (type) {
    case ActionType.BRADCART: {
      return {...state, Cart: [...state.Cart, ...payload]};
    }
    case ActionType.BRADPROD: {
      return {...state, Prod: [...state.Prod, ...payload]};
    }
    case ActionType.BRADEMPTY: {
      return {Cart: []};
    }

    case ActionType.BRADDEL: {
      console.log('payload in reducer', payload);
      const newArr = state.Cart.filter(item => item.id != payload);
      return {...state, Cart: newArr};
    }
    default:
      return state;
  }
};
