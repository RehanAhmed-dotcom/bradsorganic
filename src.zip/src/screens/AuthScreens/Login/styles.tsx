import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
  main: {
    flex: 1,
    // alignItems: 'center',
    backgroundColor: 'white',
  },
  first: {
    flex: 1,
    // backgroundColor: 'red',
    alignItems: 'center',
    justifyContent: 'center',
  },
  second: {
    flex: 2,
    // alignItems: 'center',
    // backgroundColor: 'blue',
  },
  text: {
    fontSize: 24,
    // fontWeight: 'bold',
    color: '#E06437',
  },
  inputView: {
    // backgroundColor: '#E4E4E4',
    // height: 40,
    // width: '100%',

    alignItems: 'center',
  },
  inputView1: {
    // backgroundColor: 'red',
    // height: 40,
    marginTop: 40,
    alignItems: 'center',
    // width: '100%',
  },
});
export default styles;
