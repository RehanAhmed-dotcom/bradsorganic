import React, {useState, useEffect} from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  FlatList,
  SafeAreaView,
  Image,
  TextInput,
  ActivityIndicator,
  ScrollView,
} from 'react-native';
import {useDispatch} from 'react-redux';
import {logoutuser} from '../../../redux/actions';
import {productList} from '../../../lib/api';
import styles from './styles';
import {useBottomTabBarHeight} from '@react-navigation/bottom-tabs';
import {useSelector} from 'react-redux';
import LinearGradient from 'react-native-linear-gradient';
import Icon1 from 'react-native-vector-icons/Fontisto';
import Icon from 'react-native-vector-icons/AntDesign';
// import { userdata } from '../../../redux/actions';
const Product = ({navigation}) => {
  const [index, setIndex] = useState('');
  const dispatch = useDispatch();
  const tabBarHeight = useBottomTabBarHeight();
  const data = [
    {
      id: '1',
      name: 'Blue Corn Chips',
      oz: '5.5 oz',
      type: 'GE 121',
      price: '$2.66',
    },
    {
      id: '2',
      name: 'Blue No Salt Chips',
      oz: '5.5 oz',
      type: 'GE 121',
      price: '$2.66',
    },
    {
      id: '3',
      name: 'Red Hot Blue Chips',
      oz: '5.5 oz',
      type: 'GE 121',
      price: '$2.66',
    },
    {
      id: '4',
      name: 'Multi Grain Chips',
      oz: '5.5 oz',
      type: 'GE 121',
      price: '$2.66',
    },
  ];
  const {userData} = useSelector(({USER}) => USER);
  const [products, setProducts] = useState([]);
  const [filterArr, setFilterArr] = useState([]);
  const [extra, setExtra] = useState([]);
  useEffect(() => {
    const unsubscribe = navigation.addListener('focus', () => {
      productList({Auth: userData.api_token}).then(res => {
        // console.log('resp', res.all_product[0]);
        setFilterArr(res.all_product);
        setProducts(res.data);
      });
    });
    return unsubscribe;
  }, [navigation]);
  // useEffect(() => {
  //   // const unsubscribe = navigation.addListener('focus', () => {
  //   productList({Auth: userData.api_token}).then(res => {
  //     // console.log('resp', res.all_product[0]);
  //     setFilterArr(res.all_product);
  //     setProducts(res.data);
  //   });
  //   // });
  //   // return unsubscribe;
  // }, [index]);
  const searchText = e => {
    let filteredName = [];
    if (e) {
      filteredName = filterArr.filter(item => {
        // console.log('item', item);
        return item.name.includes(e.toUpperCase());
      });
      console.log('name', filteredName);
      // setFilterArr(filteredName);
      setExtra(filteredName);
      // filteredName = [];
    }
  };
  console.log('leng', filterArr.length);
  const renderItem1 = ({item}) => (
    <View key={item.id + 'a'} style={styles.inner}>
      <View style={styles.rows}>
        <Text style={{fontWeight: 'bold', fontSize: 16}}>{item.name}</Text>
        <Text style={{color: '#9E9E9E'}}>{item.sku}</Text>
      </View>
      <View style={styles.rows}>
        <Text
          style={{
            fontSize: 12,
            fontWeight: 'bold',
            color: '#707070',
            marginTop: 10,
          }}>
          {item.longDesc}
        </Text>
        <Text
          style={{
            color: '#E06437',
            fontWeight: 'bold',
            fontSize: 12,
            marginTop: 10,
          }}>
          ${item.unitPrice}
        </Text>
      </View>
    </View>
  );
  const renderItem = ({item}) => (
    <>
      <View style={styles.topone}>
        <Text style={styles.text}>{item.category}</Text>
      </View>
      {item.products.map(items => (
        <View key={items.id + 'a'} style={styles.inner}>
          <View style={styles.rows}>
            <Text style={{fontWeight: 'bold', fontSize: 16}}>{items.name}</Text>
            <Text style={{color: '#9E9E9E'}}>{items.sku}</Text>
          </View>
          <View style={styles.rows}>
            <Text
              style={{
                fontSize: 12,
                fontWeight: 'bold',
                color: '#707070',
                marginTop: 10,
              }}>
              {items.longDesc}
            </Text>
            <Text
              style={{
                color: '#E06437',
                fontWeight: 'bold',
                fontSize: 12,
                marginTop: 10,
              }}>
              ${items.unitPrice}
            </Text>
          </View>
        </View>
        // <View>
        //   <Text>{items.name}</Text>
        // </View>
      ))}
    </>
  );
  return (
    <SafeAreaView style={[styles.main, {paddingBottom: tabBarHeight}]}>
      <View style={styles.top}>
        <View style={{width: 20}}></View>
        <Text style={{color: '#E06437', fontSize: 20}}>Products</Text>
        <TouchableOpacity onPress={() => logoutuser(false)(dispatch)}>
          <Image
            source={require('../../../assets/logout.png')}
            style={{width: 30, height: 30}}
          />
        </TouchableOpacity>
      </View>
      <TextInput
        value={index}
        onChangeText={text => {
          setIndex(text);
          searchText(text);
        }}
        placeholder={'Search Products'}
        textAlign="center"
        style={{
          width: '90%',
          backgroundColor: '#E4E4E4',
          height: 40,
          marginHorizontal: 15,
          borderRadius: 10,
          marginTop: 10,
        }}
      />
      {products.length ? (
        index ? (
          <FlatList
            data={extra}
            renderItem={renderItem1}
            keyExtractor={item => item.id}
          />
        ) : (
          <FlatList
            data={products}
            renderItem={renderItem}
            keyExtractor={item => item.category}
          />
        )
      ) : (
        <View
          style={{
            height: '80%',
            // backgroundColor: 'red',
            alignItems: 'center',
            justifyContent: 'center',
          }}>
          <ActivityIndicator size="small" color="#E06437" />
        </View>
      )}

      {/* <ScrollView>
        <View style={styles.rest}>
          <View style={styles.topone}>
            <Text style={styles.text}>Garden Of Eatin</Text>
          </View>
          <View style={{width: '100%', marginTop: 20}}>
            <FlatList
              data={data}
              renderItem={renderItem}
              keyExtractor={item => item.id}
            />
          </View>
          <View style={styles.topone}>
            <Text style={styles.text}>Brad's Organic Pretzels</Text>
          </View>
          <View style={{width: '100%', marginTop: 20}}>
            <FlatList
              data={data}
              renderItem={renderItem}
              keyExtractor={item => item.id}
            />
          </View>
          <View style={styles.topone}>
            <Text style={styles.text}>Brad's Organic</Text>
          </View>
          <View style={{width: '100%', marginTop: 20}}>
            <FlatList
              data={data}
              renderItem={renderItem}
              keyExtractor={item => item.id}
            />
          </View>
        </View>
      </ScrollView> */}
    </SafeAreaView>
  );
};
export default Product;
