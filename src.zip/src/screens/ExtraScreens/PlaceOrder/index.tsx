import React, {useState} from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  FlatList,
  Alert,
  ActivityIndicator,
  Image,
  Modal,
  SafeAreaView,
  ScrollView,
} from 'react-native';
import {useSelector, useDispatch} from 'react-redux';
import {SwipeListView} from 'react-native-swipe-list-view';
import styles from './styles';
import {bradDel, cart} from '../../../redux/actions';
import {bradCart} from '../../../redux/actions';
import {placeOrder} from '../../../lib/api';
import Icon from 'react-native-vector-icons/AntDesign';
import Icon1 from 'react-native-vector-icons/Entypo';
import GradienButton from '../../../components/GradientButton';
import {TextInput} from 'react-native-gesture-handler';
import {useEffect} from 'react';

const Input = ({itemQty, id, onChangeQty, product}) => {
  const [quantity, setQuantity] = useState(itemQty);
  // item.multQty.toString()
  useEffect(() => {
    setQuantity(itemQty);
    console.log('item qty inside input', itemQty);
  }, [product, itemQty]);
  return (
    <TextInput
      keyboardType="number-pad"
      style={{width: '100%', height: 40}}
      textAlign="center"
      value={quantity.toString()}
      onChangeText={text => {
        setQuantity(text);
        // index == 0 ? setFirst(text) : setSecond(text);
        onChangeQty(id, text);
      }}
    />
  );
};

const PlaceOrder = ({navigation, route}) => {
  const {store, pro} = route.params;
  const dispatch = useDispatch();
  const {Cart} = useSelector(({BCART}) => BCART);
  const {userData} = useSelector(({USER}) => USER);
  const [first, setFirst] = useState('12');
  const [awyn, setAwyn] = useState(0);
  const [product, setProduct] = useState([]);
  const [ind, setInd] = useState(-1);
  const [second, setSecond] = useState('12');
  const [showModal, setShowModal] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);
  console.log('s', store);
  useEffect(() => {
    setProduct(Cart);
  }, [Cart]);
  // useEffect(() => {
  //   console.log('product', product);
  // }, [product]);
  console.log('product in body ', product);

  const data1 = [
    {
      id: '1',
      name: 'Blue Corn Chips',
      oz: '5.5 oz',
      type: 'GE 121',
      price: '$2.66',
    },
    {
      id: '2',
      name: 'Blue No Salt Chips',
      oz: '5.5 oz',
      type: 'GE 121',
      price: '$2.66',
    },
  ];
  const myModal = () => (
    <Modal
      animationType="slide"
      transparent={true}
      visible={showModal}
      onRequestClose={() => {
        setShowModal(false);
      }}>
      <View style={styles.modalView}>
        <View
          style={{
            width: '80%',
            backgroundColor: 'white',
            alignItems: 'center',
            borderRadius: 15,
          }}>
          {/* <Icon1
            name="check"
            size={50}
            style={{marginTop: 50}}
            color="#EA973E"
          /> */}
          <Image
            source={require('../../../assets/check.png')}
            style={{
              height: 30,
              resizeMode: 'contain',
              marginTop: 50,
              width: 30,
            }}
          />
          <Text
            style={{
              marginTop: 20,
              color: '#E06437',
              fontSize: 20,
              fontWeight: 'bold',
            }}>
            Order Placed
          </Text>
          <Text style={{color: '#9E9E9E', marginTop: 10}}>
            You have just placed an order.
          </Text>
          <Text style={{color: '#9E9E9E', marginBottom: 25}}>
            You can view it on your home page{' '}
          </Text>
          <TouchableOpacity
            onPress={() => {
              setShowModal(false);
              navigation.navigate('TabNavigator');
            }}
            style={{width: '100%', alignItems: 'center'}}>
            <GradienButton title={'G R E A T !'} />
          </TouchableOpacity>
          <View style={{height: 25}} />
        </View>
      </View>
    </Modal>
  );
  const myModal1 = () => (
    <Modal animationType="slide" transparent={true} visible={modalVisible}>
      <View
        style={{
          flex: 1,
          backgroundColor: '#00000088',
          alignItems: 'center',
          justifyContent: 'center',
        }}>
        <View
          style={{
            height: 50,
            width: 50,
            borderRadius: 25,
            alignItems: 'center',
            backgroundColor: 'white',
            justifyContent: 'center',
          }}>
          <ActivityIndicator size="small" color="#E06437" />
        </View>
      </View>
    </Modal>
  );
  const deleteItem = id => {
    const newArr = product.filter(item => item.id != id);
    console.log('newArr after delet', newArr);
    // setProduct(newArr);
  };

  const addQty = id => {
    const prod = product.find(item => item.id == id);
    const index = product.findIndex(i => i.id == id);

    const newPro = {
      ...prod,
      multQty: parseInt(prod.multQty) + 12,
    };
    product[index] = newPro;
  };

  const subQty = id => {
    const prod = product.find(item => item.id == id);
    const index = product.findIndex(i => i.id == id);

    const newPro = {
      ...prod,
      multQty: parseInt(prod.multQty) - 12,
    };
    product[index] = newPro;
    // console.log('this is index', index);
  };

  const onChangeQty = (id, quantity) => {
    const prod = product.find(item => item.id == id);
    const index = product.findIndex(i => i.id == id);

    const newPro = {
      ...prod,
      multQty: parseInt(quantity),
    };
    product[index] = newPro;
  };

  const renderItem1 = ({item, index}) => (
    <>
      <TouchableOpacity
        // onPress={() => {}}
        // onPressOut={() => setInd(index)}
        style={styles.inner}>
        <View style={styles.rows}>
          <Text style={{fontWeight: 'bold', fontSize: 16}}>{item.name}</Text>
          <Text style={{color: '#9E9E9E', fontSize: 16}}>{item.sku}</Text>
        </View>
        <View style={styles.rows}>
          <Text style={{fontSize: 12, color: '#707070', fontWeight: 'bold'}}>
            {item.longDesc}
          </Text>
          <Text
            style={{
              color: '#E06437',
              fontWeight: 'bold',
              fontSize: 12,
              marginTop: 10,
            }}>
            ${item.unitPrice}
          </Text>
        </View>
      </TouchableOpacity>
      <View style={styles.quantity}>
        <TouchableOpacity
          onPress={() => {
            subQty(item.id);
            // console.log('multQty', item.multQty);
            const firstValue = parseInt(first) - 12;
            const secondValue = parseInt(second) - 12;
            index == 0
              ? setFirst(firstValue.toString())
              : setSecond(secondValue.toString());
          }}
          style={styles.plus}>
          <Image
            source={require('../../../assets/minuus.png')}
            style={{height: 20, width: 20}}
          />
          {/* <Icon name="minus" size={20} color="orange" /> */}
        </TouchableOpacity>
        <View style={styles.middle}>
          {/* <Text>{index == 0 ? first : second}</Text> */}
          {/* <TextInput
            keyboardType="number-pad"
            style={{width: '100%', height: 40}}
            textAlign="center"
            value={item.multQty.toString()}
            onChangeText={text => {
              // index == 0 ? setFirst(text) : setSecond(text);
              onChangeQty(item.id, text);
            }}
          /> */}
          <Input
            product={product}
            itemQty={item.multQty}
            id={item.id}
            onChangeQty={(id, text) => onChangeQty(id, text)}
          />
        </View>
        <TouchableOpacity
          onPress={() => {
            addQty(item.id);

            const firstValue = parseInt(first) + 12;
            const secondValue = parseInt(second) + 12;
            index == 0
              ? setFirst(firstValue.toString())
              : setSecond(secondValue.toString());
          }}
          style={styles.plus}>
          <Image
            source={require('../../../assets/plus.png')}
            style={{height: 15, width: 15}}
          />
          {/* <Icon name="plus" size={20} color="orange" /> */}
        </TouchableOpacity>
      </View>
    </>
  );
  return (
    <SafeAreaView style={styles.main}>
      <View style={styles.top}>
        <TouchableOpacity onPress={() => navigation.navigate('NewOrder')}>
          <Image
            source={require('../../../assets/back.png')}
            style={{height: 20, width: 20, resizeMode: 'contain'}}
          />
          {/* <Icon name="arrowleft" color="orange" size={20} /> */}
        </TouchableOpacity>
        <Text style={{color: '#E06437', fontSize: 20}}>New Order</Text>
        <TouchableOpacity>
          {/* <Icon name="arrowleft" color="white" /> */}
        </TouchableOpacity>
      </View>

      {/* <ScrollView> */}
      <View style={styles.rest}>
        <View style={{width: '100%', marginTop: 10}}>
          <View style={styles.inner}>
            <View style={styles.rows}>
              <Text style={{fontWeight: 'bold'}}>{store.value}</Text>
              {/* <Text style={{color: 'grey'}}>{item.type}</Text> */}
            </View>
            <View style={styles.rows}>
              <Text style={{fontSize: 12, color: '#707070'}}>
                {store.address}
              </Text>
              {/* <Text style={{color: 'orange', fontSize: 12, marginTop: 10}}> */}
              {/* {item.price} */}
              {/* </Text> */}
            </View>
          </View>
          <TouchableOpacity
            onPress={() => {
              // bradCart(product)(dispatch);
              navigation.navigate('SelectQuantity');
            }}
            style={styles.topButton}>
            <Text style={{color: '#E06437'}}>Select Products</Text>
          </TouchableOpacity>
        </View>
      </View>
      <ScrollView>
        <View style={styles.rest}>
          {/* <View style={styles.topone}>
            <Text style={styles.text}>Garden Of Eatin</Text>
          </View> */}
          <View style={{width: '100%', marginTop: 10}}>
            <SwipeListView
              data={Cart}
              rightOpenValue={-75}
              //   leftOpenValue={75}
              renderHiddenItem={({item}) => (
                <View
                  style={{
                    // backgroundColor: 'red',
                    marginTop: 20,
                    flexDirection: 'row',
                    justifyContent: 'flex-end',
                    paddingRight: 10,
                    marginHorizontal: 15,
                  }}>
                  <TouchableOpacity
                    onPress={() => bradDel(item.id)(dispatch)}
                    style={{
                      backgroundColor: 'red',
                      height: 50,
                      width: 50,
                      alignItems: 'center',
                      borderRadius: 10,
                      justifyContent: 'center',
                    }}>
                    <Image
                      source={require('../../../assets/trash.png')}
                      style={{height: 20, width: 20}}
                    />
                  </TouchableOpacity>
                </View>
              )}
              renderItem={renderItem1}
              keyExtractor={item => item.id}
            />
          </View>
        </View>
      </ScrollView>
      {/* </ScrollView> */}
      <TouchableOpacity
        disabled={Cart.length ? false : true}
        onPress={() => {
          console.log('cart length', Cart.length);
          setModalVisible(true);
          const newArr = [];
          product.forEach(element => {
            newArr.push({
              product_id: element.id,
              quantity: element.multQty,
            });
          });
          const data1 = {
            store_id: store.id,
            cart: newArr,
          };
          placeOrder({Auth: userData.api_token}, data1).then(res => {
            console.log(res);
            if (res) {
              if (res.status == 'success') {
                setModalVisible(false);
                setShowModal(true);
              }
            } else {
              setModalVisible(false);
              Alert.alert('Something went wrong');
            }
          });
        }}
        style={styles.bottom}>
        <GradienButton title={'P L A C E  O R D E R'} />
      </TouchableOpacity>
      {myModal()}
      {myModal1()}
    </SafeAreaView>
  );
};
export default PlaceOrder;
