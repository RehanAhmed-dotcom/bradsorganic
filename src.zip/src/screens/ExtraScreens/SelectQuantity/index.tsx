import React, {useState, useEffect} from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  FlatList,
  SafeAreaView,
  TextInput,
  ActivityIndicator,
  Image,
  ScrollView,
} from 'react-native';

import {bradCart} from '../../../redux/actions';
import styles from './styles';
import {
  heightPercentageToDP as hp,
  widthPercentageToDP,
} from 'react-native-responsive-screen';
import {productList} from '../../../lib/api';
import {SwipeListView} from 'react-native-swipe-list-view';
import Icon from 'react-native-vector-icons/AntDesign';
import GradientButton from '../../../components/GradientButton';
import {useSelector, useDispatch} from 'react-redux';

const Product = ({item, onPress, pro, isInclude}) => {
  // console.log(pro, 'sdfk');
  // console.log('checking includes', pro.includes(item));
  return (
    <TouchableOpacity
      // onPress
      onPress={onPress}
      style={[
        styles.inner,
        {borderWidth: 1, borderColor: isInclude ? '#E06437' : 'white'},
      ]}>
      <View style={styles.rows}>
        <Text style={{fontWeight: 'bold', fontSize: 16}}>{item.name}</Text>
        <Text style={{color: '#9E9E9E', fontSize: 16}}>{item.sku}</Text>
      </View>
      <View style={styles.rows}>
        <Text
          style={{
            fontSize: 12,
            color: '#707070',
            fontWeight: 'bold',
            marginTop: 10,
          }}>
          {item.longDesc}
        </Text>
        <Text
          style={{
            color: '#E06437',
            fontWeight: 'bold',
            fontSize: 12,
            marginTop: 10,
          }}>
          ${item.unitPrice}
        </Text>
      </View>
    </TouchableOpacity>
  );
};

const SelectQuantity = ({navigation, route}) => {
  const {store} = route.params;
  const dispatch = useDispatch();
  const [index, setIndex] = useState('');
  const [filterArr, setFilterArr] = useState([]);
  const [extra, setExtra] = useState([]);
  const [number, setNumber] = useState(12);
  const [products, setProducts] = useState([]);
  const [pro, setPro] = useState([]);
  const [categoryProd, setCategoryProd] = useState([]);

  const findProdAndCategory = item => {
    let newArr = [];
    const findItem = categoryProd.find(
      (categoryItem: any) => categoryItem.category === item.category,
    );

    if (findItem) {
      newArr = categoryProd.map((cartItem: any) => {
        if (cartItem.category === item.category) {
          newArr = [...categoryProd];
          const index = categoryProd.findIndex(
            i => i.category === cartItem.category,
          );
          newArr[index].products.push(item);
          setCategoryProd(newArr);
          return newArr;
        } else {
          return cartItem;
        }
      });
    } else {
      newArr = [{category: item.category, products: [item]}];
      setCategoryProd(newArr);
    }
    // console.log('category products', categoryProd);
    // console.log('new array with', newArr);
    // let arr = [];
    // if (categoryProd.length) {
    //   const newArr = categoryProd.map(catItem => {
    //     // console.log('cat item', catItem);
    //     if (catItem.category === item.category) {
    //       console.log('inside if block');
    //       const index = categoryProd.findIndex(
    //         i => i.category === catItem.category,
    //       );
    //       console.log('index', index);
    //       categoryProd[index].products.push(item);
    //     } else {
    //       console.log('inside else block');
    //       setCategoryProd([
    //         ...categoryProd,
    //         {category: item.category, products: [item]},
    //       ]);
    //     }
    //   });
    //   console.log('new array', newArr);
    //   console.log('category prod', categoryProd);
    // } else {
    //   console.log('else block of top func');
    //   setCategoryProd([{category: item.category, products: [item]}]);
    // }
  };
  const searchText = e => {
    let filteredName = [];
    if (e) {
      filteredName = filterArr.filter(item => {
        // console.log('item', item);
        return item.name.includes(e.toUpperCase());
      });
      console.log('name', filteredName);
      // setFilterArr(filteredName);
      setExtra(filteredName);
      // filteredName = [];
    }
  };
  const {userData} = useSelector(({USER}) => USER);
  const {Cart} = useSelector(({BCART}) => BCART);
  const renderItem2 = ({item}) => (
    <TouchableOpacity
      onPress={() => console.log(Cart.includes(item.name))}
      key={item.id + 'a'}
      style={[
        styles.inner,
        {
          borderWidth: 1,
          borderColor: '#E06437',
        },
      ]}>
      <View style={styles.rows}>
        <Text style={{fontWeight: 'bold', fontSize: 16}}>{item.name}</Text>
        <Text style={{color: '#9E9E9E'}}>{item.sku}</Text>
      </View>
      <View style={styles.rows}>
        <Text
          style={{
            fontSize: 12,
            fontWeight: 'bold',
            color: '#707070',
            marginTop: 10,
          }}>
          {item.longDesc}
        </Text>
        <Text
          style={{
            color: '#E06437',
            fontWeight: 'bold',
            fontSize: 12,
            marginTop: 10,
          }}>
          ${item.unitPrice}
        </Text>
      </View>
    </TouchableOpacity>
  );
  const renderItem1 = ({item, index}) => (
    <>
      <View style={styles.topone}>
        <Text style={styles.text}>{item.category}</Text>
      </View>
      <FlatList
        // key={item.category + 'a'}
        data={item.products}
        // rightOpenValue={-100}
        // onMagicTap={() => console.log('work now')}
        // onSwipeValueChange
        // onResponderRelease
        // onRowOpen={() => console.log('work now')}
        // onEndReached
        // onScrollEndDrag
        // renderHiddenItem={item => (
        //   <View
        //     style={{
        //       // backgroundColor: 'red',
        //       marginTop: 10,
        //       flexDirection: 'row',
        //       justifyContent: 'flex-end',
        //       alignItems: 'center',
        //       // backgroundColor: 'red',
        //       height: '100%',
        //       paddingRight: 10,
        //       bottom: 10,
        //       marginHorizontal: 15,
        //     }}>
        //     <TouchableOpacity
        //       onPress={() => number > 12 && setNumber(number - 12)}>
        //       <Image
        //         source={require('../../../assets/negative.png')}
        //         style={{width: 15, height: 3}}
        //       />
        //     </TouchableOpacity>
        //     <View
        //       style={{
        //         backgroundColor: '#ccc',
        //         alignItems: 'center',
        //         justifyContent: 'center',
        //         height: 30,
        //         marginLeft: 10,
        //         marginRight: 10,
        //         borderRadius: 10,
        //         width: 30,
        //       }}>
        //       <Text>{number}</Text>
        //     </View>
        //     <TouchableOpacity onPress={() => setPro([...pro, {}])}>
        //       <Image
        //         source={require('../../../assets/plus.png')}
        //         style={{width: 15, height: 15}}
        //       />
        //     </TouchableOpacity>
        //   </View>
        // )}
        renderItem={({item}) => (
          <Product
            pro={pro}
            item={item}
            onPress={() => {
              // pro[index] != item && setPro([...pro, item]);
              // findProdAndCategory(item);
              bradCart([item])(dispatch);
              console.log('item', Cart.includes(item));
            }}
            isInclude={Cart.includes(item)}
          />
        )}
        keyExtractor={item => item.id}
      />
    </>
  );
  // console.log('pro', pro);
  const renderItem = ({item, index}) => (
    <TouchableOpacity
      // onPress
      onPress={() => {
        // pro[index] != item && setPro([...pro, item]);
        // findProdAndCategory(item);
      }}
      style={[
        styles.inner,
        {borderWidth: 1, borderColor: pro.includes(item) ? 'orange' : 'white'},
      ]}>
      <View style={styles.rows}>
        <Text style={{fontWeight: 'bold', fontSize: 16}}>{item.name}</Text>
        <Text style={{color: '#9E9E9E', fontSize: 16}}>{item.sku}</Text>
      </View>
      <View style={styles.rows}>
        <Text
          style={{
            fontSize: 12,
            color: '#707070',
            fontWeight: 'bold',
            marginTop: 10,
          }}>
          {item.longDesc}
        </Text>
        <Text
          style={{
            color: '#E06437',
            fontWeight: 'bold',
            fontSize: 12,
            marginTop: 10,
          }}>
          ${item.unitPrice}
        </Text>
      </View>
    </TouchableOpacity>
  );

  useEffect(() => {
    // const unsubscribe = navigation.addListener('focus', () => {
    productList({Auth: userData.api_token}).then(res => {
      // console.log('res', res.data[4].products);
      setProducts(res.data);
      console.log('check', res.all_product[0]);
      setFilterArr(res.all_product);
    });
    // });
    // return unsubscribe;
  }, []);
  console.log('BCAER', Cart);
  return (
    <SafeAreaView style={styles.main}>
      <ScrollView>
        <View style={styles.rest}>
          <TextInput
            value={index}
            onChangeText={text => {
              setIndex(text);
              searchText(text);
            }}
            placeholder={'Search Products'}
            textAlign="center"
            style={{
              width: '90%',
              backgroundColor: '#E4E4E4',
              height: 40,
              marginHorizontal: 15,
              borderRadius: 10,
              marginTop: 10,
            }}
          />
          {products.length ? (
            <View style={{marginHorizontal: 0}}>
              {index ? (
                <View
                  style={{
                    // backgroundColor: 'red',
                    marginTop: 10,
                    width: widthPercentageToDP('100%'),
                    paddingHorizontal: 15,
                  }}>
                  <FlatList
                    data={extra}
                    renderItem={({item}) => (
                      <Product
                        pro={pro}
                        item={item}
                        onPress={() => {
                          // pro[index] != item && setPro([...pro, item]);
                          // findProdAndCategory(item);
                          bradCart([item])(dispatch);
                          // console.log('item', Cart.includes(item.name));
                        }}
                        isInclude={Cart.includes(item)}
                      />
                    )}
                    keyExtractor={item => item.id}
                  />
                </View>
              ) : (
                <View style={{marginHorizontal: 15}}>
                  <FlatList
                    data={products}
                    renderItem={renderItem1}
                    keyExtractor={item => item.id}
                  />
                </View>
              )}
            </View>
          ) : (
            // products.map((item, index) => (
            //   <>
            //     <View style={styles.topone}>
            //       <Text style={styles.text}>{item.category}</Text>
            //     </View>
            //     <FlatList
            //       // key={item.category + 'a'}
            //       data={item.products}
            //       // rightOpenValue={-100}
            //       // onMagicTap={() => console.log('work now')}
            //       // onSwipeValueChange
            //       // onResponderRelease
            //       // onRowOpen={() => console.log('work now')}
            //       // onEndReached
            //       // onScrollEndDrag
            //       // renderHiddenItem={item => (
            //       //   <View
            //       //     style={{
            //       //       // backgroundColor: 'red',
            //       //       marginTop: 10,
            //       //       flexDirection: 'row',
            //       //       justifyContent: 'flex-end',
            //       //       alignItems: 'center',
            //       //       // backgroundColor: 'red',
            //       //       height: '100%',
            //       //       paddingRight: 10,
            //       //       bottom: 10,
            //       //       marginHorizontal: 15,
            //       //     }}>
            //       //     <TouchableOpacity
            //       //       onPress={() => number > 12 && setNumber(number - 12)}>
            //       //       <Image
            //       //         source={require('../../../assets/negative.png')}
            //       //         style={{width: 15, height: 3}}
            //       //       />
            //       //     </TouchableOpacity>
            //       //     <View
            //       //       style={{
            //       //         backgroundColor: '#ccc',
            //       //         alignItems: 'center',
            //       //         justifyContent: 'center',
            //       //         height: 30,
            //       //         marginLeft: 10,
            //       //         marginRight: 10,
            //       //         borderRadius: 10,
            //       //         width: 30,
            //       //       }}>
            //       //       <Text>{number}</Text>
            //       //     </View>
            //       //     <TouchableOpacity onPress={() => setPro([...pro, {}])}>
            //       //       <Image
            //       //         source={require('../../../assets/plus.png')}
            //       //         style={{width: 15, height: 15}}
            //       //       />
            //       //     </TouchableOpacity>
            //       //   </View>
            //       // )}
            //       renderItem={({item}) => (
            //         <Product
            //           pro={pro}
            //           item={item}
            //           onPress={() => {
            //             pro[index] != item && setPro([...pro, item]);
            //             findProdAndCategory(item);
            //           }}
            //           isInclude={pro.includes(item)}
            //         />
            //       )}
            //       keyExtractor={item => item.id}
            //     />
            //   </>
            // ))
            <View
              style={{
                height: hp(100),
                // backgroundColor: 'red',
                alignItems: 'center',
                justifyContent: 'center',
              }}>
              <ActivityIndicator size="small" color="#E06437" />
            </View>
          )}
        </View>
      </ScrollView>
      <TouchableOpacity
        onPress={() =>
          Cart.length && navigation.navigate('PlaceOrder', {store})
        }
        style={styles.bottom}>
        <GradientButton title={'A D D  Q U A N T I T Y'} />
      </TouchableOpacity>
    </SafeAreaView>
  );
};
export default SelectQuantity;
